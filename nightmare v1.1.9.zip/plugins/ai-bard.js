/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from 'axios'

let handler = async (m, {conn, text, usedPrefix, command}) => {
let teks 
if (m.quoted) {
teks = m.quoted.text
} else if (text) {
teks = text
} else throw `[ invalid ]\n*gunakan command*:\n${usedPrefix+command} presiden Indonesia`

try {
m.reply(wait)

const { data } = await axios.get(`https://api-nightmares.my.id/api/bard?text=${text}&apikey=Tio`)

if (data.status == false) throw 'kode 404'
conn.sendThumb(m.chat, data.hasil, 'https://telegra.ph/file/b7464bac089ffbe6fee74.jpg', m)

} catch (e) {
throw eror
}

}
handler.help = handler.command = ['bard']
handler.tags = ['ai']
handler.limit = handler.register = true

export default handler