import axios from 'axios';
import uploadImage from '../lib/uploadImage.js';
import fetch from 'node-fetch';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
  const name = await conn.getName(who);
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  if (!mime) throw 'Kirim/Reply Gambar dengan caption .bing2img';

  m.reply('Tunggu Sebentar...');

  try {
    const media = await q.download();
    const url = await uploadImage(media);
    const hasil = await fetch(`https://api.itsrose.life/image/stable/prompter?url=${url}&apikey=${global.rose}`);
    const json = await hasil.json();

    async function postData(url, data) {
      try {
        const response = await axios.post(url, data);
        console.log('Response:', response.data);
        return response.data;
      } catch (error) {
        console.error('Error:', error.message);
        throw error;
      }
    }

    const bingUrl = 'https://api.itsrose.life/image/bing_create_image?apikey=' + global.rose;
    const data = {
      "prompt": json.result.prompt
    };

    postData(bingUrl, data)
      .then(response => {
        for (const image of response.result.images) {
          conn.sendFile(m.chat, image, '', `*Bing 2 img result*`, m);
        }
      })
      .catch(error => {
        console.error('Error:', error.message);
        // Tangani kesalahan jika terjadi
      });
  } catch (e) {
    m.reply("Terjadi kesalahan");
  }
};

handler.command = handler.help = ["bing2img"];
handler.tags = ["ai"];
handler.premium = false;
export default handler;