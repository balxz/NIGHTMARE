/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import fetch from 'node-fetch'
import FormData from 'form-data'
import cheerio from 'cheerio'

let handler = async (m, {
    conn,
    usedPrefix,
    text,
    args,
    command
}) => {

let teks
if (m.quoted) {
teks = m.quoted ? m.quoted.text : m.quoted.text
} else if (text) {
teks = text ? text : text
} else throw `[!] *input salah*\ngunakan : ${usedPrefix + command} presiden Indonesia`


            try {
            await m.react('💬')
                const { data } = await openai(teks);

                if (data) {
                    await m.reply(data);
                   await m.react('✅')
                } else {
                    console.log("Tidak ada respons dari Gemini-Ai atau terjadi kesalahan.");
                }
            } catch (error) {
                m.react('❎')
            }
}
handler.tags = ["ai"];
handler.limit = handler.register = true
handler.help = ['openai']
handler.command = /^(openai|ai)$/i

export default handler;

async function getInfo() {
    const url = 'https://chatopenai.me';

    try {
        const html = await (await fetch(url)).text();
        const $ = cheerio.load(html);

        const chatData = $('.wpaicg-chat-shortcode').map((index, element) => {
            return Object.fromEntries(Object.entries(element.attribs));
        }).get();

        return chatData;
    } catch (error) {
        throw new Error('Error:', error.message);
    }
}

async function openai(message) {
    try {
        const info = await getInfo();
        const data = new FormData();
        data.append('_wpnonce', info[0]['data-nonce']);
        data.append('post_id', info[0]['data-post-id']);
        data.append('action', 'wpaicg_chatbox_message');
        data.append('message', message);
        const response = await fetch('https://chatopenai.me/wp-admin/admin-ajax.php', {
            method: 'POST',
            body: data
        });

        if (!response.ok) throw new Error('Network response was not ok');

        return await response.json();
    } catch (error) {
        console.error('An error occurred:', error.message);
        throw error;
    }
}