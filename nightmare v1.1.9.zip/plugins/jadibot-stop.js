import fs from 'fs'
const data = fs.readFileSync('./function/database/jadibot.json');
let json = JSON.parse(data);

let handler = async (m, {conn, usedPrefix, command}) => {
if (!json.includes === m.sender) throw `Kamu sedang tidak menjadi Bot cloning`
try {
            json.splice(json.indexOf(m.chat), 1);
            fs.writeFileSync('./function/database/jadibot.json', JSON.stringify(json));
            await deleteFolder('./plugins/jadibot/'+m.sender.split(`@`)[0])
            await conn.reply(m.chat, `Sukses *stop jadibot*`, m);
            return json;
} catch (e) {
throw eror
}
}
handler.help = handler.command = ['stopadibot']
handler.tags = ['main']

export default handler

function deleteFolder(path) {
  if (fs.existsSync(path)) {
    fs.readdirSync(path).forEach((file, index) => {
      const curPath = path + '/' + file;
      if (fs.lstatSync(curPath).isDirectory()) {
        deleteFolder(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(path);
    console.log('Folder berhasil dihapus.');
  } else {
    console.log('Folder tidak ditemukan.');
  }