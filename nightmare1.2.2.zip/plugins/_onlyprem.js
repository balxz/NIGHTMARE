let handler = m => m
handler.before = async function(m, {
    conn,
    isROwner
}) {
    if (m.chat.endsWith('broadcast')) return
    if (m.fromMe) return
    if (m.isGroup) return
    let bot = db.data.settings[conn.user.jid]
    if (bot.onlyprem) {
        
        let user = global.db.data.users[m.sender]
        if (user.premium) {
            user.banned = false
        } else {
            if (isROwner) {
                user.banned = false
            } else {
                user.banned = true
                await m.reply(`📢 Kamu tidak dapat mengakses fitur ❗\nBeli premium untuk mengakses lewat PC`)
            }
        }
    }
}

export default handler