/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = m => m

handler.before = async function (m, {conn}) {
if (!m.isGroup) return !0
 // if (m.isBaileys && m.fromMe) return true

  let chat = global.db.data.chats[m.chat];
  
  if (!m.isBaileys && !m.fromMe) return !0
  if (chat.antiBot) { 
  await conn.reply(m.chat, "*[ BOT LAIN TERDETEKSI ]*", m);
await conn.delay(1000)
  await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");  
}
}

export default handler