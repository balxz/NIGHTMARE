import axios from "axios";
let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text)
        throw `Apa yang pengen kamu tanyain?\n\nContoh: ${
            usedPrefix + command
        } halo bot`;

try {
await m.react('💬')
 let d = new Date(new Date + 3600000)
let locale = 'id'
const jam = new Date().toLocaleString("en-US", {timeZone: "Asia/Jakarta"});
let hari = d.toLocaleDateString(locale, { weekday: 'long' })
let tgl = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let json = await chatWithGPT(
        [
            {
                role: "assistant",
                content:
                    `Nama kamu adalah Merry, kamu dibuat dan dikembangkan oleh Tio. Gunakan bahasa gaul seperti mata gue dan lu dalam menjawab semua pertanyaan orang. selalu bersikap cerdas. Gunakan emoji yang sesuai dalam setiap kalimat. Gunakan tanggal ${tgl}. Gunakan jam ${jam}. Gunakan hari ${hari}.`
            },
            {
                role: "user",
                content: text
            }
        ],
        text
    );
    m.reply(`\> ✨${json}`);
await m.react('🔥')
} catch (e) {
await m.react('❎')
}
};

handler.help = ["ai <teks>"];
handler.tags = ["information"];
handler.command = /^(ai)$/i;

export default handler;

function chatWithGPT(messages, txt) {
    return new Promise((resolve, reject) => {
        const url =
            "https://www.freechatgptonline.com/wp-json/mwai-ui/v1/chats/submit";
        const body = {
            botId: "default",
            messages,
            newMessage: txt,
            stream: false
        };

        axios
            .post(url, body)
            .then(response => {
                resolve(response.data.reply);
            })
            .catch(error => {
                resolve(error.data.message);
            });
    });
}