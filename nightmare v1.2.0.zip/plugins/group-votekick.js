let handler = async (m, { conn, args }) => {
    let who;
    
    if (m.quoted && m.quoted.sender) {
        who = m.quoted.sender;
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        who = m.mentionedJid[0];
    } else {
        throw `Who do you want to vote for?`;
    }

    const groupOwner = await (await conn.groupMetadata(m.chat)).owner;
    const tag = await (await conn.groupMetadata(m.chat)).participants.map(a => a.id);

    if (who === m.sender || who === groupOwner || who === conn.user.jid) {
        throw `You can't vote for the group creator or yourself!`;
    }

    let user = global.db.data.users[who];

    if (user.lastVotedBy === m.sender) {
        throw `You can't vote for the same person again during the voting period!`;
    }
    if (!user.votekick) {
    user.votekick = 0
    }
    user.lastVotedBy = m.sender;
    user.votekick += 1;
    
    let cap = `@${m.sender.split("@")[0]} Have voted for @${who.split("@")[0]} to be removed!\n*Voting Total:* ${user.votekick}/5`;

    if (user.votekick >= 5) {
        cap += `\n\nThe user has reached 5 votes and has been removed from the group.`;
        conn.groupParticipantsUpdate(m.chat, [who], "remove");
        user.votekick = 0;
    } else {
        let timeout = setTimeout(() => {
            user = global.db.data.users[who];
            user.lastVotedBy = '';
            user.votekick = 0;
            conn.reply(m.chat, `Voting for @${who.split("@")[0]} has ended. The target of 5 votes was not reached.`, m, { contextInfo: {
            mentionedJid: [who]
            } });
        }, 5 * 60 * 1000);
        user.votingTimeout = timeout;
    }
    
    conn.reply(m.chat, cap, null, { contextInfo:
    {
     mentionedJid: [m.sender, who] 
     }});
};

handler.help = ['vote_kick']
handler.command = /^(vote_kick|vk|votekick)$/i;
handler.tags = ['group'];
handler.group = true;
handler.botAdmin = true;

export default handler;