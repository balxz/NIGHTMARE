/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})( [0-9]{1,3})?/i

let handler = async (m, { text, args, usedPrefix, command }) => {
let teks = text.split(' ')
    if (!teks[0] || isNaN(teks[0])) throw `Masukkan Angka Mewakili Jumlah Hari !\n*Misal : ${usedPrefix + command} 30*`
    if (args[1]) {
     let [_, code] = teks[1] ? teks[1].match(linkRegex) || [] : '' 
     if (!code) throw 'Link invalid'
     
      let res = await conn.groupAcceptInvite(code)
         
         }
    let who
    if (m.isGroup) who = teks[1] ? res : m.chat
    else who = m.chat

    var jumlahHari = 86400000 * teks[0]
    var now = new Date() * 1
    if (now < global.db.data.chats[who].expired) global.db.data.chats[who].expired = jumlahHari
    else global.db.data.chats[who].expired = now + jumlahHari
    conn.reply(m.chat, `Berhasil Menetapkan Hari Kadaluarsa Untuk Grup Ini Selama ${teks[0]} Hari.\n\nHitung Mundur : ${msToDate(global.db.data.chats[who].expired - now)}`, m)
}
handler.help = ['addsewa']
handler.tags = ['owner']
handler.command = /^(addsewa)$/i
handler.rowner = true
handler.group = false

export default handler

function msToDate(ms) {
    let temp = ms
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / (1000));
    return days + " Hari " + hours + " Jam " + minutes + " Menit";
    // +minutes+":"+sec;
}