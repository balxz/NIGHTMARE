/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import { DisconnectReason,  useMultiFileAuthState, fetchLatestBaileysVersion, toBuffer, makeInMemoryStore, PHONENUMBER_MCC, makeCacheableSignalKeyStore } from '@adiwajshing/baileys'
import WebSocket from 'ws'
import qrcode from 'qrcode'
import NodeCache from 'node-cache'
import { makeWASocket, protoType, serialize } from '../lib/simple.js'
import stor from '../lib/store.js'
let msgRetryCounterCache = new NodeCache();
import pino from 'pino' 
import fs from 'fs' 
const data = fs.readFileSync('./function/database/jadibot.json');
let json = JSON.parse(data);
    
let store = makeInMemoryStore({
  logger: pino().child({
    level: "silent",
    stream: "store",
  }),
});

import { createRequire } from 'module' 
import { groupsUpdate } from '../handler.js'
let handlers = (await import('../handler.js'))
        
const isNumber = x => typeof x === 'number' && !isNaN(x)
global.tryConnect = []
if (global.conns instanceof Array) console.log()
else global.conns = []

let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {

  let conns = global.conn

if(conn.user.jid !== conns.user.jid) return m.reply('Tidak bisa membuat Bot pada user jadibot!')

//if (!global.users[m.sender].acc) return m.reply('Nomor kamu belum di Acc Owner, silahkan chat owner')

    let auth = false
    let authFile = 'plugins/jadibot/' + m.sender.split("@")[0]
    let isInit = !fs.existsSync(authFile)
    let id = global.conns.length
    let { state, saveCreds } = await useMultiFileAuthState(authFile)
    let { version } = await fetchLatestBaileysVersion()

const config = {
  version: version,
  printQRInTerminal: false,
    logger: pino({
      level: "silent",
    }),
    browser: ['Linux', 'Chrome', ''],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(
        state.keys,
        pino({ level: "fatal" }).child({ level: "fatal" }),
      ),
    },
    browser: ['Linux', 'Chrome', ''], // for this issues https://github.com/WhiskeySockets/Baileys/issues/328
    markOnlineOnconnect: true, // set false for offline
    generateHighQualityLinkPreview: true, // make high preview link
    getMessage: async (key) => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);

      return msg?.message || "";
    },
    msgRetryCounterCache, // Resolve waiting messages
    defaultQueryTimeoutMs: undefined, // for this issues https://github.com/WhiskeySockets/Baileys/issues/276

    }

  const delay = (time) => new Promise((res) => setTimeout(res, time));
  
 const fake = {
			key: {
				participant: '0@s.whatsapp.net',
				...(m.chat ? {
					remoteJid: `status@broadcast`
				} : {})
			},
			message: {
				locationMessage: {
					name: `CLONING BOT`,
					jpegThumbnail: fs.readFileSync('./src/avatar_contact.png')
				}
			}
		}
		
  const teks = `*Input kode ini untuk menjadi Bot (Clone)*

  *Langkah-langkah untuk memindai:*
  *1.- Ketuk tiga titik di sudut kanan atas di beranda WhatsApp Anda*
  *2.- Ketuk WhatsApp web atau perangkat yang sudah terhubung*
  *4.- Klik Tautkan dengan nomor telepon saja*
  *3.- Masukan kode*

  *Jika belum terkoneksi ketik \`\`\`/jadibot\`\`\`, dan tunggu sampai terkoneksi. Jangan melakukan spam jadibot untuk menghindari ERROR pada sistem Bot Nightmare MD*`;


  store.bind(conn.ev);
    conn = makeWASocket(config)
    let ev = conn.ev

    let date = new Date()
    let timestamp = date.getHours() + ':' + date.getMinutes() + ' ' + date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear()
    conn.timestamp = timestamp

  if (!conn.authState.creds.registered) {
    let phoneNumber = m.sender.split("@")[0].replace(/[^0-9]/g, "");
    

    if (
      !Object.keys(PHONENUMBER_MCC).some((v) => phoneNumber.startsWith(v))
    )
      throw "Start with your country's WhatsApp code, Example : 62xxx";
      await delay(2000)
    let code = await conn.requestPairingCode(phoneNumber);
    code = code?.match(/.{1,4}/g)?.join("-") || code;
     //conns.sendFile(m.chat, 'https://telegra.ph/file/b3b9c8dad1c61da0a6dda.jpg', '', teks, m)
    //await delay(1000)
    conns.reply(m.chat, "*Your Code :* " + code, fake)
    
  }


  async function needUpdate(update) {
    const { connection, lastDisconnect, qr} = update

    if (lastDisconnect && lastDisconnect.error && lastDisconnect.error.output && lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut && conn.ws.readyState !== WebSocket.CONNECTING) {
            global.tryConnect(true)
            m.reply('Connecting...')
        } else if(connection === 'open'){
          conns.reply(m.chat, `Berhasil mengkoneksikan dengan WhatsApp.\n*NOTE: Cloning Bot by Nightmare MD*\nNomor: ${conn.user.jid.split`@`[0]}\nJoin: ${timestamp}\n`, m)
            global.tryConnect[m.sender] = 0
            global.conns[m.sender] = conn
            if (!json.includes(m.sender)) {
     json.push(m.sender)
    fs.writeFileSync('./function/database/jadibot.json', JSON.stringify(json));
    return json
    }
        } else if(connection === 'close'){
          m.reply('koneksi terputus!! wait...') 
        } else {
          m.reply('Report Owner! BugError: '+lastDisconnect)
        }
    }
  
    function tryConnect(restatConn, close) { 
	
        conn.welcome = 'Hai, @user!\nSelamat datang di grup @subject\n\n@desc'
        conn.bye = 'Selamat tinggal @user!'
        conn.spromote = '@user sekarang admin!'
        conn.sdemote = '@user sekarang bukan admin!'
        conn.handler = handlers.handler.bind(conn)
      conn.connectionUpdate = needUpdate.bind(conn)
        conn.credsUpdate = saveCreds.bind(conn)
        //conn.onCall = handlers.onCall.bind(conn)
        conn.onGroupUpdate = groupsUpdate.bind(conn)

        if (restatConn) {
            try { conn.ws.close() } catch { }
            conn = {
                ...conn, ...makeWASocket(config)
            }
        }

        if (!isInit || !close) {
            ev.off('messages.upsert', conn.handler)
            ev.off('group-participants.update', conn.onGroupUpdate)
            ev.off('connection.update', conn.connectionUpdate)
            ev.off('creds.update', conn.credsUpdate)
            //ev.off('call', conn.onCall)
        }
        ev.on('messages.upsert', conn.handler)
        ev.on('connection.update', conn.connectionUpdate)
        ev.on('creds.update', conn.credsUpdate)
        //ev.on('call', conn.onCall)
        ev.on('group-participants.update', conn.onGroupUpdate)
        isInit = false
        return true
    }
    await tryConnect()
}
handler.help = ['jadibot']
handler.tags = ['main']
handler.command = /^(jadibot)$/i
handler.premium = true 
export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)