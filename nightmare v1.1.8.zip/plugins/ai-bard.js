/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import fetch from 'node-fetch'
import { GoogleBard } from '../scraper/Bard.js'

let handler = async (m, {conn, text, usedPrefix, command}) => {

let teks 
if (m.quoted) {
teks = m.quoted.text
} else if (text) {
teks = text
} else throw `[ invalid ]\n*gunakan command*:\n${usedPrefix+command} presiden Indonesia`

try {
m.reply(wait)
let eng = await tran(teks, 'en');
const result = await GoogleBard(eng);
let id = await tran(result[0], 'id');

if (!id[0]) throw 'kode 404'
conn.sendAdd(m.chat, id[0], command, '', 'https://telegra.ph/file/b7464bac089ffbe6fee74.jpg', m)

} catch (e) {
throw eror
}

}
handler.help = handler.command = ['bard']
handler.tags = ['ai']
handler.limit = handler.register = true

export default handler

async function tran(query = "", lang) {
	if (!query.trim()) return "";
	const url = new URL("https://translate.googleapis.com/translate_a/single");
	url.searchParams.append("client", "gtx");
	url.searchParams.append("sl", "auto");
	url.searchParams.append("dt", "t");
	url.searchParams.append("tl", lang);
	url.searchParams.append("q", query);

	try {
		const response = await fetch(url.href);
		const data = await response.json();
		if (data) {
			return [data[0].map((item) => item[0].trim()).join("\n"), data[2]];
		} else {
			return "";
		}
	} catch (err) {
		throw err;
	}
}