let handler = m => m

handler.before = async function (m, {conn}) {
  let chat = global.db.data.chats[m.chat];
  if (m.fromMe) return 
  
  if (chat.antiBot && m.isBaileys == true) { 
  await conn.reply(m.chat, "*[ BOT LAIN TERDETEKSI ]*", m);
await conn.delay(1000)
  await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");  
}
}

export default handler