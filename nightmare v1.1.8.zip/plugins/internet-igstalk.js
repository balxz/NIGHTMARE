/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from 'axios'

let handler = async (m, {
    usedPrefix,
    command,
    conn,
    text
}) => {
    let input = `[!] *wrong input*
	
Ex : ${usedPrefix + command} tulisan.ku.id`
    if (!text) return m.reply(input)

    try {
        const {
            data
        } = await axios.get(`https://instasupersave.com/api/ig/userInfoByUsername/${text}`);
        const res = data.result.user

        conn.sendMessage(m.chat, {
            text: `乂 I G S T A L K

*Username*: ${res.username} 
*Fullname*: ${res.full_name} 
*Post_count*: ${res.media_count} 
*Followers*: ${res.follower_count} 
*Following*: ${res.following_count}
*Verifed*: ${res.is_verified}
*Private*: ${res.is_private}

*external_url*: ${res.external_url} 
*Biography*: ${res.biography} 
`,
            contextInfo: {
                "externalAdReply": {
                    "title": 'Instagram Stalk',
                    "body": `click here to account`,
                    previewType: "PHOTO",
                    showAdAttribution: true,
                    sourceUrl: `https://instagram.com/${text}`,
                    thumbnailUrl: res.hd_profile_pic_url_info.url
                }
            }
        }, {
            quoted: m
        })
    } catch (err) {
        m.reply(err + '\nsalah nickname mungkin!')
    }
}
handler.help = ['igstalk']
handler.tags = ['stalker']
handler.command = /^(igstalk|instagramstalk)$/i
handler.limit = true
export default handler