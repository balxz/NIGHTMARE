import './config.js'
import fs from 'fs'

export async function web(ig, owner, namebot) {
try {
var html = `
<!DOCTYPE html>
<html>
<head>
  
<link rel="canonical" href="https://www.nightmare.my.id">
    <title>Dashboard Nightmare Bot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        
        .header {
          text-align: center;
            background-color: #0009d2;
            color: #ffffff;
            border-radius: 10px;
            border: 2px solid black;
            padding: 10px;
        }
        
        .navigation {
            text-align: center;
            background-color: #0009d2;
            border-radius: 40px;
            position: absolute;
            right: 45px; 
            top: 355px;
            padding: 5px;
        }
        
             .navigation2 {
            text-align: center;
            background-color: #0009d2;
            border-radius: 40px;
            position: absolute;
            left: 45px; 
            top: 355px;
            padding: 5px;
        }
        
        .navigation a {
            color: #ffffff;
            text-decoration: none;
            margin-right: 0px;
        }
        
                .navigation2 a {
            color: #ffffff;
            text-decoration: none;
            margin-right: 0px;
        }
        
        .content {
            background-color: #ffffff8d;
            border: 2px solid black;
            border-radius: 5px;
            padding: 20px;
            margin: 20px;
        }
        
        .info-bar {
            background-color: #f2f2f2;
            height: 10px;
            margin-bottom: 30px;
            margin-top: 30px;
        }
        
        .info-bar .percent {
            width: 0;
            height: 100%;
            border-radius: 5px;
            background-color: green;
        }
        
        .info-bar .text {
            float: top;
            margin-top: -30px;
            
        }
        
        footer {
            background-color: #ffffff;
            color: #000000;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        
        body {
font-family: Arial, sans-serif;
background-color: #f2f2f2;
background-image: url('https://telegra.ph/file/bd27644525d39b0883b9a.jpg');
background-repeat: no-repeat;
background-position: center;
background-size: ;
width: 95%;
height: 50vh;
}
            .info {
      margin-bottom: 10px;
    }

    .info span {
      font-weight: bold;
    }

    .info .value {
      margin-left: 10px;
    }

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  
}
    </style>
    
    <script>
      function play() {
//Link Audio Bisa Diganti
  var audio = new Audio('https://media.vocaroo.com/mp3/1gL2w937aHK6');audio.play();
  audio.loop=false;audio.addEventListener('ended', function() {this.currentTime = 0;this.play();}, false);
}         
// auto play lagu
play()

    </script>
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>$(function() {
  // Get the current time
  var now = new Date();

  // Format the time
  var formattedTime = now.toLocaleTimeString();

  // Display the time
  $("#time").html(formattedTime);
});</script>
    
<body>
    <div class="header">
        <h1>Dashboard Informasi</h1>
        <div>Thank you for using script Nightmare Md</div>
    </div>
    <div class="navigation">
        <a href="https://www.instagram.com/${ig}">Instagram</a>
    </div>
    <div class="navigation2">
      <a href="https://wa.me/${owner}">WhatsApp</a>
    </div>
    <div class="content">
        <h2>Information</h2>
        <div class="info">
          <span>Name Bot:</span>
          <span class="value">${namebot}</span>
        </div>
        
        <div class="info">
          <span>Time:</span>
          <span class="value" id="time"></span>
        </div>
        
        <div class="info">
          <span>IP address:</span>
          <span class="value" id="ip"></span>
        </div>
        
    </div>
    
 <script>
      // Mengambil informasi alamat IP pada sisi klien
      const ipInfoElement = document.getElementById('ip');
      fetch('https://api.ipify.org/?format=json')
      .then(response => response.json())
      .then(data => {
        ipInfoElement.innerText = data.ip;
      })
      .catch(error => {
        console.log('Gagal mengambil informasi alamat IP:', error);
        ipInfoElement.innerText = 'Tidak dapat mengambil informasi';
      });
    </script>
    </div>
    <div class="container">
    <footer>
      <p style="font-size: 15px">
        Copyright &copy; by Nightmare MD. Unauthorized reproduction or distribution is strictly prohibited.
      </p>
      </footer>
      </div>
    </body>
</body>
</html>

`
const htmll = await fs.writeFileSync('./index.html', html)
const result = await fs.readFileSync('./index.html')
return result
} catch (e) {
console.log('gagal membuat file')
}
}