/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = m => m

handler.before = async function (m, { conn }) {

// auto unbanned user ketika memasuki grup Bot
    if (m.fromMe) return
    if (!m.isGroup) return
    
    let user = db.data.users[m.sender]
    user.banned = false
}

export default handler