/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import fetch from 'node-fetch'

export async function before (m, { conn, args, text, usedPrefix, command }) {
let d = new Date(new Date + 3600000)
    let locale = 'id'
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    })
return date
let link = 'https://data.bmkg.go.id/DataMKG/TEWS/'
let data = db.data.settings[conn.user.jid]
if (m.fromMe) return
    if (!m.isGroup) return
    if (data.update_gempa) return 
		let res = await fetch(link+'autogempa.json')
		let anu = await res.json()
		anu = anu.Infogempa.gempa
		let txt = `*${anu.Wilayah}*\n\n`
		txt += `Tanggal : ${anu.Tanggal}\n`
		txt += `Waktu : ${anu.Jam}\n`
		txt += `Potensi : *${anu.Potensi}*\n\n`
		txt += `Magnitude : ${anu.Magnitude}\n`
		txt += `Kedalaman : ${anu.Kedalaman}\n`
		txt += `Koordinat : ${anu.Coordinates}${anu.Dirasakan.length > 3 ? `\nDirasakan : ${anu.Dirasakan}` : ''}`
		 if (anu.tangall == date) {
		await conn.sendMessage(m.chat, {text: txt , contextInfo:
					{
						"externalAdReply": {
							"title": 'UPDATE GEMPA',
							"body": date,
							"showAdAttribution": true,
							"mediaType": 1,
							"sourceUrl": sgc,
							"thumbnail": await (await conn.getFile(link + anu.Shakemap)).data,
							"renderLargerThumbnail": true
														

						}
					}}, { quoted: m })
					} else console.log('nothing update')
		}