import { tiktokStalk } from '../scraper/scrape.js'

let handler = async (m, {usedPrefix, command, conn, text }) => {

if (!text) throw `Error!\nMasukan username, *Ex: ${usedPrefix + command} mrbeast`
try {
await tiktokStalk(text).then(async(res) => {
if (!res.status) return m.reply('Error Username tidak ditemukan\nSilahkan kirim Username yang valid!')
let teks = `乂  *STALKER TIKTOK*

◦  Username: ${res.username}
◦  Nickname : ${res.nickname}
◦  Followers : ${res.followers}
◦  Following : ${res.following}
◦  Likes : ${res.likes}
◦  Description : ${res.desc}`
await conn.sendMessage(m.chat, {image: {url : res.profile}, caption: teks}, {quoted: m})
}).catch((e) => m.reply('Username tidak ditemukan!'))
} catch (err) {
m.reply('Error Username tidak ditemukan\nSilahkan kirim Username yang valid!')
}

}
handler.help = ['stalktiktok <username>']
handler.tags = ['stalker']
handler.command = /^(tiktokstalk|stalktiktok|ttstalk)$/i
handler.limit = true
export default handler