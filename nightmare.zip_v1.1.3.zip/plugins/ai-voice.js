/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from 'axios'
import fetch from 'node-fetch'

let handler = async (m, {
    conn,
    isOwner,
    usedPrefix,
    command,
    args,
    text
}) => {
const id_voice = db.data.settings[conn.user.jid]

const apiKey = ['6bbb1b5f94a16d31819e712ce47fda74', 'f3b29b5f3c8e1c1a8b4b797041bacac6', 'e315c09c6b41976733b2f8b133f57b6c', '0c0d3c5e1be30b201f205fcc9cc6229b', '425857c94525f9f2ffd29bd892c963e3', 'ec9aaca1b37ff537981d1b57d864ecc7', 'c8002c223e14765ec29e544b86cc45c8', 'e9c85e0451170a7f7d0f99928dffc123', '2bfe3b63d234a653218039212520db24', 'c90e7bb63810925ff039e364f1f82dd1', '3187701e93909b9cd59ef3799f1b1bba', '1b1f848cdbacf5ce34ed74badbe21dbe', '2a10a1e7371f711f6396a934d7db8145', '940068d6d62ed017af3041daf32eb560','8abf05dd9197c3411f28056c2f9c7bfb']

if (!text) return m.reply(`[❗] invalid text\n${usedPrefix+command} halo kak`)

try {
conn.sendMessage(m.chat, {react: {text: '🕛', key: m.key}})
const query = m.quoted && m.quoted.text ? `pesan sebelumnya: "${m.quoted.text}"\n\n${text}` : `${text}`;
        const apiUrl = `https://api.azz.biz.id/api/alicia?q=${encodeURIComponent(query)}&user=${m.chat}&key=alok`;

        const respon = await fetch(apiUrl);
        const res = await respon.json();
        
    const options = {
  method: 'POST',
  headers: {'xi-api-key': await pickRandom(apiKey),'Content-Type': 'application/json'},
responseType: "arraybuffer",
  data: {"model_id": `eleven_multilinguel_v2`,
  "text": `${res.respon}`,
  "voice_settings": {
  "similarity_boost": 1,
  "stability":1,
  "style":1,
  "use_speaker_boost":true
  }}
};
const response = await axios(`https://api.elevenlabs.io/v1/text-to-speech/oWAxZDx7w5VEj9dCyTzz?optimize_streaming_latency=4&output_format=mp3_44100_96`, options)

let audio = {
    audio: response.data,
    mimetype: 'audio/mp4',
    ptt: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: 'AI VOICE',
        body: '',
        sourceUrl: '',
        thumbnail: await (await conn.getFile('https://telegra.ph/file/2de4b511af9c0130fdf96.jpg')).data,
        renderLargerThumbnail: true
      }
    }
  };

  conn.sendMessage(m.chat, audio, { quoted: m })
  conn.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
  
  } catch (e) {
  conn.sendMessage(m.chat, {react: {text: '❗', key: m.key}})
  
  m.reply(eror)
  }
}
handler.help = ["ai-voice"]
handler.tags = ["speech","ai"]
handler.command = /^(aiv|ai-v(oice)?)$/i
handler.limit = 5
export default handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}