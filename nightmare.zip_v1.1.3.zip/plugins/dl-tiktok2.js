/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from "axios"
import { tiktokdl } from '../scraper/tiktokdl.js'
import { Tiktok } from '../scraper/tiktok.js'

let handler = async (m, { conn, args, usedPrefix, text, command}) => {
let input = `List type:
  ⛒ v2 (mp4 + mp3)
  ⛒ v3 (wm)
    
${usedPrefix + command} https://vm.tiktok.com/ZSL7p9jRV/`

let type = (args[0] || '').toLowerCase()
if (!text) return m.reply(input)

switch (type) {
case 'v2':
if (!args[1]) return m.reply(input)

if (!(args[1].includes('http://') || text.includes('https://'))) return m.reply(`url invalid, please input a valid url. Try with add http:// or https://`)

if (!args[1].includes('tiktok.com')) return m.reply(`Invalid Tiktok URL.`)

const { data } = (
        await axios.post(
          "https://ezsave.app/api/tiktok/video-downloader",
          {
            url: args[1],
          },
          {
            headers: { "Content-Type": "application/json" },
          }
        )
      ).data;
conn.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})

let cap = `*${data[0].title}*

duration: ${data[0].duration}
url: ${args[1]}
●───//──────●
  *TIK TOK V2*
    
`

let v2 = await conn.sendFile(m.chat, data[0].url || emror, 'eror.mp4', cap, m)

 conn.sendMessage(m.chat, {react: {text: '✔️', key: m.key}})


break
case 'v3':
if (!args[1]) return m.reply(input)

if (!(args[1].includes('http://') || text.includes('https://'))) return m.reply(`url invalid, please input a valid url. Try with add http:// or https://`)

if (!args[1].includes('tiktok.com')) return m.reply(`Invalid Tiktok URL.`)

conn.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})
const { title, author, nowm, watermark, audio, thumbnail} = await Tiktok(args[1])
let capv3 = `   乂 *TIK TOK V3*

    ᨔ Name: ${author}
    ᨔ Type: no watermark 
`
let vid = await conn.sendFile(m.chat, watermark || emror, 'eror.mp4', capv3, m)
await conn.sendMessage(m.chat, {audio: {url: audio}}, {quoted: m}).then(_ => {
conn.sendMessage(m.chat, {react: {text: '✔️', key: m.key}})
      })

break
default:
if (!text) return m.reply(input)
if (!text.includes('tiktok.com')) return m.reply(`Invalid Tiktok URL.`)

conn.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})
const { status, caption, server1, serverHD } = await tiktokdl(text);
if (status === true) {
const cap = `    乂 *TIK TOK V1*

quality: ${server1.quality}
url: ${text}

`

await conn.sendFile(m.chat, server1.url || emror, '', cap, m).then(_ => {
conn.sendMessage(m.chat, {react: {text: '✔️', key: m.key}})
    })
    
    } else {
    m.reply(eror)
    }
    
  }
  }
handler.help = ['v1','v2','v3(wm)'].map(v => `tiktok2 ${v} <link>`)
handler.tags = ['downloader']
handler.command = /^(tiktok2|tt2(dl|download)?)$/i
handler.limit = true
handler.register = true

export default handler