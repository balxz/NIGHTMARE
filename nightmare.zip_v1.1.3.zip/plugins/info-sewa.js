/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = async (m, {
    conn,
    text,
    args,
    command,
    usedPrefix 
}) => {
const list = `⋄ sᴇᴡᴀ ɴɪɢʜᴛᴍᴀʀᴇ ᴍᴅ ⋄

[ 1 ] 2k / 2hari 
[ 2 ] 5k / Minggu 
[ 3 ] 15k / bulan 
[ 4 ] 45k / permanen
[ 5 ] 50k / permanen + premium (30 hari)

 Via Dana: 082285357346
 Qris: not yet available 
 Gopay: 082285357346
 Owner: wa.me/6282285357346
  
 *Note*: chat owner untuk sewa Bot
                   Bot selalu Ter Up To Date

 anda membeli = setuju 😃
`

conn.sendFile(m.chat, 'https://telegra.ph/file/cf1c9bce36f1890e1d458.jpg', '', list, m)
}
handler.help = handler.command = ['sewa','sewabot']
handler.tags = ['main']
export default handler