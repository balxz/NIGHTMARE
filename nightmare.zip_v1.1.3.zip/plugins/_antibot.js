/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = m => m

handler.before = async function (m) {
  let chat = global.db.data.chats[m.chat];
  if (chat.antiBot) {
if (m.formMe) return 
    if (m.isBaileys == true) {
        await conn.reply(m.chat, "*[ ANOTHER BOT DETECTED ]*", m);
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
      }
      return ;
    }
  }
export default handler