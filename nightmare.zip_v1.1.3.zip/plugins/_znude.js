/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

const isToxic = /(nude|bokep|peler|sex|seks|porno|porn|naked|kontol|bkp|bokp|memek|mmk|hot)/i;

export async function before(m, { conn, isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe)
        return !0
    if (!m.isGroup) return !1
    let users = db.data.users
    const nudee = isToxic.exec(m.text)
    let on = true
    if (on && nudee) {
users[m.sender].banned = true
    
  await conn.sendMessage(m.chat, {react: {text: '⚠️', key: m.key}})
    }
    
}