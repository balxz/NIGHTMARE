/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
let exec = promisify(_exec).bind(cp);

let handler = async (m, { 
 conn,
 isOwner,
 command,
  text 
  }) => {
  
  if (global.conn.user.jid != conn.user.jid) return;
  conn.sendMessage(m.chat, {react: {text: '🔓', key: m.key}})
  const teks = text ? text : ''
  const compressedFilePath = `nightmare_v${teks}.zip`
  if (!fs.existsSync(compressedFilePath)) {
    try {
      await exec(`zip -r nightmare_v${teks}.zip app.json config.js database.json Docker handler.js function_web.js index.html index.js lib main.js package.json plugins Procfile scraper server.js sessions src test.js`);
      conn.sendMessage(m.chat, {react: {text: '🔒', key: m.key}})
      await conn.delay(1000)
      conn.sendMessage(m.chat, {react: {text: '🔐', key: m.key}})
     
    } catch (e) {
      conn.sendMessage(m.chat, {react: {text: '❎', key: m.key}})
      return; 
    }
  } else {
    m.reply(`nightmare_v${teks}.zip already exists, skipping creation..._`);
  }

const fake = {
key: { fromMe: false, participant: m.sender, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) }, message: { "documentMessage": { "title": await style('BACKUP SCRIPT', 5),"h": `Hmm`, 'jpegThumbnail': await conn.resize(logo, 100, 100)}}
}

  // Check again if the file exists after compression attempt
  if (fs.existsSync(compressedFilePath)) {
    const compressedData = fs.readFileSync(compressedFilePath);
    await conn.sendMessage(
      m.sender,
      {
        document: compressedData,
        mimetype: 'application/zip',
        fileName: `nightmare_v${teks}.zip`,
        caption: 'The backup file will be deleted ❗',
      },
      {
        quoted: fake,
      }
    );
  } else {
    m.reply('File not found. Compression may have failed.');
  }
  await fs.unlinkSync(compressedFilePath)
};

handler.help = ['backup'];
handler.tags = ['owner'];
handler.command = /^(backup)$/i;
handler.rowner = true;

export default handler;