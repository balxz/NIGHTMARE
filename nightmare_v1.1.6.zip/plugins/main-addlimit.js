/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = async (m, { conn, command, text, args }) => {
if (!text) throw 'nomor/tag!'
let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : args [0] + '@s.whatsapp.net'
else who = m.sender
    let users = global.db.data.users
    users[who].limit += args[1] ? args[1] : 250
    conn.reply(m.chat, `sukses menambah limit sebanyak ${args[1] ? args[1] : 250} !`, m)
}
handler.help = ['addlimit']
handler.tags = ['owner']
handler.command = /^addlimit(user)?$/i
handler.premium = true

export default handler