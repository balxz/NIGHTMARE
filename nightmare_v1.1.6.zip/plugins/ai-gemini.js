/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

let handler = async (m, {
    conn,
    usedPrefix,
    text,
    args,
    command
}) => {

    let input = `[!] *wrong input*
	
Ex : ${usedPrefix + command} presiden Indonesia`
    const react = {
        react: {
            text: "⏳",
            key: m.key
        }
    }
    const reactdone = {
        react: {
            text: "✔️",
            key: m.key
        }
    }
    async function reload() {
        conn.sendMessage(m.chat, react)
    }
    async function done() {
        conn.sendMessage(m.chat, reactdone)
    }

            if (!text) throw input

            try {
            
            reload()
                const openAIResponse = await gemini(text);

                if (openAIResponse) {
                    console.log("Respons dari OpenAI:");
                    await m.reply(openAIResponse);
                    done()
                } else {
                    console.log("Tidak ada respons dari Gemini-Ai atau terjadi kesalahan.");
                }
            } catch (error) {
                console.error("Terjadi kesalahan:", error);
                await m.reply(error);
            }
}
handler.tags = ["ai"];
handler.limit = handler.register = true
handler.help = ['gemini-ai']
handler.command = /^(gemini(ai)?)$/i

export default handler;


const { GoogleGenerativeAI } = (await import("@google/generative-ai"));
const genAI = new GoogleGenerativeAI('AIzaSyDR-Vh4DcRCWg2MVgPmXSh-mBZKzO-DSJw');
    
const gemini = async (text) => {
    let model = genAI.getGenerativeModel({ model: "gemini-pro" });
    let result = await model.generateContent(text);
    let response = await result.response;
    let hasil = response.text();
    return hasil
}