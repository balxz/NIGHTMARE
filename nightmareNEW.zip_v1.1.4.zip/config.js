/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import { watchFile, unwatchFile } from 'fs'
import fs from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Owner
global.owner = [
['6282285357346', 'Tio', true]
] 
global.mods = []
global.prems = []
// Info
global.nomerbot = '6281231804035'
global.nomorwa = '6282285357346'
global.nameown = 'Tioo'
global.nomerown = '6282285357346'
global.packname = 'sticker by '
global.author = 'N I G H T M A R E'
global.namebot = '乂 NightMare - MD'
global.wm = 'N I G H T M A R E  -  M D'
global.stickpack = 'Whatsapp'
global.stickauth = 'Bot - MD'
// Thumbnail 
global.ppKosong = 'https://i.ibb.co/3Fh9V6p/avatar-contact.png'
global.didyou = 'https://telegra.ph/file/fdc1a8b08fe63520f4339.jpg'
global.rulesBot = 'https://telegra.ph/file/afcfa712bd09f4fcf027a.jpg'

global.thumbnail = 'https://telegra.ph/file/07428fea2fd4dccaab65f.jpg'
global.thumb = 'https://telegra.ph/file/89f925eaab0ab2d0f001a.jpg'
global.logo = 'https://telegra.ph/file/07428fea2fd4dccaab65f.jpg'

global.unReg = 'https://telegra.ph/file/ef02d1fdd59082d05f08d.jpg'
global.registrasi = 'https://telegra.ph/file/0169f000c9ddc7c3315ff.jpg'
global.confess = 'https://telegra.ph/file/03cabea082a122abfa5be.jpg'
global.access = 'https://telegra.ph/file/5c35d4a180b9074a9f11b.jpg'
global.tqto = 'https://telegra.ph/file/221aba241e6ededad0fd5.jpg'
global.spotify = 'https://telegra.ph/file/d888041549c7444f1212b.jpg'
global.weather = 'https://telegra.ph/file/5b35ba4babe5e31595516.jpg'
global.gempaUrl = 'https://telegra.ph/file/03e70dd45a9dc628d84c9.jpg'
global.akses = 'https://telegra.ph/file/6c7b9ffbdfb0096e1db3e.jpg'
// wel/good
global.wel = 'https://telegra.ph/file/9dbc9c39084df8691ebdd.mp4'
global.good = 'https://telegra.ph/file/1c05b8c019fa525567d01.mp4'
// Sosmed
global.sig = 'https://instagram.com/tulisan.ku.id'
global.sgh = 'https://github.com/sadxzyq'
global.sgc = 'https://chat.whatsapp.com/GitU9r4OiQJ0v2hRYfs576'
// ambil idgc ketik di grup lu 
// => m.chat 
global.idgc = '120363201971227409@g.us'
// Donasi
global.psaweria = '-'
global.ptrakterr = '-'
global.pdana = '082285357346'
// Info Wait
global.wait = '*Wait a moment*'
global.eror = '*We have some problems*!'
global.multiplier = 69
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
      let emot = {
      agility: '🤸‍♂️',
      arc: '🏹',
      armor: '🥼',
      bank: '🏦',
      bibitanggur: '🍇',
      bibitapel: '🍎',
      bibitjeruk: '🍊',
      bibitmangga: '🥭',
      bibitpisang: '🍌',
      bow: '🏹',
      bull: '🐃',
      cat: '🐈',
      chicken: '🐓',
      common: '📦',
      cow: '🐄',
      crystal: '🔮',
      darkcrystal: '♠️',
      diamond: '💎',
      dog: '🐕',
      dragon: '🐉',
      elephant: '🐘',
      emerald: '💚',
      exp: '✉️',
      fishingrod: '🎣',
      fox: '🦊',
      gems: '🍀',
      giraffe: '🦒',
      gold: '👑',
      health: '❤️',
      horse: '🐎',
      intelligence: '🧠',
      iron: '⛓️',
      keygold: '🔑',
      keyiron: '🗝️',
      knife: '🔪',
      legendary: '🗃️',
      level: '🧬',
      limit: '🌌',
      lion: '🦁',
      magicwand: '⚕️',
      mana: '🪄',
      money: '💵',
      mythic: '🗳️',
      pet: '🎁',
      petFood: '🍖',
      pickaxe: '⛏️',
      pointxp: '📧',
      potion: '🥤',
      rock: '🪨',
      snake: '🐍',
      stamina: '⚡',
      strength: '🦹‍♀️',
      string: '🕸️',
      superior: '💼',
      sword: '⚔️',
      tiger: '🐅',
      trash: '🗑',
      uncommon: '🎁',
      upgrader: '🧰',
      wood: '🪵'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string));
    if (!results.length) return '';
    else return emot[results[0][0]];
  }
}

// Apikey
global.uptime = 'u1926789-7d5be0f640d2beef922590f7'
global.xyro = 'vRFLiyLPWu'
global.fxc = 'Frieren'
global.lol = 'GataDios' //GataDios
global.rose = 'Rk-83ba3adcfcc7af3b28ec46ec_free_tier'

global.APIs = {
    xyro: "https://api.xyroinee.xyz",
    rose: "https://itsrose.life",
    fxc: "https://api-fxc7.cloud.okteto.net",
    lol: "https://api.lolhumaan.xyz"
}

//Apikey
global.APIKeys = {
    "https://api.xyroinee.xyz": "vRFLiyLPWu",
    "https://itsrose.life": "Rk-83ba3adcfcc7af3b28ec46ec_free_tier",
    "https://api-fxc7.cloud.okteto.net": "Frieren",
    "https://api.lolhumaan.xyz": "GataDios"
    
}


let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})