/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

/*
set template by tioo
*/

let handler = async (m, { conn, text, args, usedPrefix, command }) => {

// Database 
    const menu = global.db.data.settings[conn.user.jid]
    
    // Style font
    const steil = await style(`   _Template not found_ \n\n *List template :*\n\nsetMenu:\n\n1. image\n2. gif\n3. teks\n4. document\n\nsetWelcome:\n\n1. gcImage\n2. gcGif\n3. gcTeks\n4. gcDoc\n\n${global.namebot}`, 1)
    
    // Type 
    let type = (args[0] || '').toLowerCase()
    
        // Command 
    switch (type) {
    case 'image':
    
    menu.image = true
    menu.gif = false
    menu.teks = false
    menu.doc = false
    m.reply(`Success change template *Image*`)
break 
    case 'gif':
    
    menu.image = false
    menu.gif = true
    menu.teks = false
    menu.doc = false
    m.reply(`Success change template *Gif*`)
break 
    case 'teks':
    
    menu.image = false
    menu.gif = false
    menu.teks = true
    menu.doc = false
    m.reply(`Success change template *Text*`)
break 
    case 'doc': case 'document':
    
    menu.image = false
    menu.gif = false
    menu.teks = false
    menu.doc = true
    m.reply(`Success change template *Document*`)
    ///batas menu
break 
    case 'gcimage': case 'gcimg':
    
    menu.gcImg = true
    menu.gcGif = false
    menu.gcTeks = false
    menu.gcDoc = false
    m.reply(`Success change template welcome *Group Image*`)
break 
    case 'gcgif':
    
    menu.gcImg = false
    menu.gcGif = true
    menu.gcTeks = false
    menu.gcDoc = false
    m.reply(`Success change template welcome *Group Gif*`)
break 
    case 'gcteks':
    
    menu.gcImg = false
    menu.gcGif = false
    menu.gcTeks = true
    menu.gcDoc = false
    m.reply(`Success change template welcome *Group Text*`)
break 
    case 'gcdoc': case 'gcdocument':
    
    menu.gcImg = false
    menu.gcGif = false
    menu.gcTeks = false
    menu.gcDoc = true
    m.reply(`Success change template welcome *Group Document*`)
break 
    
    default:
    return await conn.sendThumb(m.chat, steil, thumbnail, m)
    
    }
}
handler.help = ["image","gif","teks","doc"].map(v => `setmenu ${v}`)
handler.tags = ['owner']
handler.command = /^(set(emplate)?)$/i

handler.group = false
handler.rowner = true

export default handler