/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import fs from 'fs';
import { webcrack } from 'webcrack';

let handler = async (m ,{ conn, text }) => {
	let teks = m.quoted.text
	if (!text) throw `[!] Enter the encryption code`
	try {
		let result = await webcrack(teks);
		m.reply(result.code)
	} catch (e) {
		console.log(e)
		throw "Error: *code invalid!*"
	}
}
handler.help = ["deobfuscator"]
handler.tags = ["tools"]
handler.command = /^deobfuscator|dencrypt|denc$/i

handler.premium = true

export default handler