const { BingImageCreator } = await(await import('../scraper/bing-image.js'));

const handler = async (m, {
	conn,
	args,
	usedPrefix,
	command
}) => {
	let text;
	if (args.length >= 1) {
		text = args.slice(0).join(" ");
	} else if (m.quoted && m.quoted.text) {
		text = m.quoted.text;
	} else {
		throw 'Input teks atau reply teks!';
	}

	await m.reply(wait);
try {
		const res = new BingImageCreator({ cookie: "1sc8hnyk1Ja1k5f6o-G8JBlmfgdQwNMX0AFjmgg_3PQJsgqVRf8Ny4dUQld7eZ1Qbf8_2sCS34pXH2GIe61GL0K4RpXnqzUD5cdcRi5FnLAgJpaErQRMxBNh2fkTMOidke4J4SWt60J6X04LxPOt6AjiLoFUQKrHOzEsrZ0m3Cv4A4aFkTOjKJAkSxKr9hZXfd9Ej_hXICa7jO_8H9nw01g" });
		const data = await res.createImage(text);
		if (data.length > 0) {
			for (let i = 0; i < data.length; i++) {
				try {
					if (!data[i].endsWith('.svg')) {
						await conn.sendFile(
							m.chat,
							data[i],
							'',
							`Image *(${i + 1}/${data.length - 1})*\n\n*Prompt*: ${text}`,
							m,
							false, {
								mentions: [m.sender],
							}
						);
					}
				} catch (error) {
					console.error(`Error sending file: ${error.message}`);
					await m.reply(`Failed to send image *(${i + 1}/${data.length})*`);
				}
			}
		} else {
			await m.reply('No images found.');
		}
	} catch (error) {
		console.error(`Error in handler: ${error.message}`);
		await m.reply(`${error}\n\n${error.message}`)
	}
};

handler.help = ["bing-img *[query]*"];
handler.tags = ["ai"];
handler.command = /^(bing(img|-img|-image|image)?)$/i;
handler.premium = true
export default handler;