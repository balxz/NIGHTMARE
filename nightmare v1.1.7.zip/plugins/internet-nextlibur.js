/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import axios from 'axios'

let handler = async (m, {conn}) => {

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

m.reply(wait)
try {
let teks = `*${(await nexLibur()).nextLibur}*\n\n${readMore}`
let result = (await nexLibur())
let no = 1
for (let a of result.libnas_content) {
teks += `${no++}. Ringkasan: ${a.summary}
Hari: ${a.days}
Bulan: ${a.dateMonth}\n\n`
}
conn.reply(m.chat, teks, m)
} catch (e) {
throw eror
}
}
handler.help = handler.command = ['harilibur','nextlibur']
handler.tags = ['internet']

export default handler

async function nexLibur() {
  const { data } = await axios.get("https://www.liburnasional.com/");
  let libnas_content = [];
  let $ = cheerio.load(data);
  let result = {
    nextLibur:
      "Hari libur" +
      $("div.row.row-alert > div").text().split("Hari libur")[1].trim(),
    libnas_content,
  };
  $("tbody > tr > td > span > div").each(function (a, b) {
    summary = $(b).find("span > strong > a").text();
    days = $(b).find("div.libnas-calendar-holiday-weekday").text();
    dateMonth = $(b).find("time.libnas-calendar-holiday-datemonth").text();
    libnas_content.push({ summary, days, dateMonth });
  });
  return result;
}