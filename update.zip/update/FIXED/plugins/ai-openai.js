import axios from "axios";
let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    if (!text)
        throw `Apa yang pengen kamu tanyain?\n\nContoh: ${
 usedPrefix + command
 } halo bot`;

    try {
        await m.react('💬')
        let json = await ai(text);

        await m.reply(`\> ✨${json}`).then(() => {
            m.react('🔥')
        })
    } catch (e) {
        await m.react('❎')
    }
};

handler.help = ["ai <teks>", "openai"];
handler.tags = ["ai"];
handler.command = /^(openai|ai)$/i;
handler.limit = true

export default handler;

const IP = () => {
    const octet = () => Math.floor(Math.random() * 256);
    return `${octet()}.${octet()}.${octet()}.${octet()}`;
};

async function ai(text) {
    try {
        const {
            data: res
        } = await axios.post("https://chatgpt4online.org/wp-json/mwai/v1/start_session", {}, {
            headers: {
                'Content-Type': 'application/json',
                "x-forwarded-for": await IP()
            }
        })

        const url = 'https://chatgpt4online.org/wp-json/mwai-ui/v1/chats/submit';
        const data = {
            botId: "chatbot-qm966k",
            customId: null,
            session: "N/A",
            messages: [{
                role: "user",
                content: text
            }],
            newMessage: text,
            stream: false
        };

        const headers = {
            'Content-Type': 'application/json',
            'X-WP-Nonce': res.restNonce,
            "x-forwarded-for": await IP()
        };

        // Send chat message
        const response = await axios.post(url, data, {
            headers: headers
        });

        if (response.status === 200) {
            return response.data.reply;
        } else {
            console.error('Error:', response.statusText);
        }
    } catch (error) {
        console.error('Axios Error:', error);
    }
}