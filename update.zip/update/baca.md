buat yang pake vps ga bisa install modul ketik ini

npm install gyp -g

# disclaimer 
Kode handler sudah fix untuk cmd bot nya (bot tidak akan merespon cmd dari bot sendiri)